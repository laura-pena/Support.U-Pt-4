//
//  ViewController.swift
//  Support.U
//
//  Created by Sonal Bhatia on 8/11/20.
//  Copyright © 2020 Sonal Bhatia. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func getStarted(_ sender: UIButton) {
    }
    
}

